package com.example.plango.user.service;

public interface UserInfoService {
    int USER_ID_LENGTH=15;
    int MAX_NICKNAME_LENGTH=20;
}
