package com.example.plango.infra.redis.model;

public enum RedisKeyType {
    BLACKLIST
}
