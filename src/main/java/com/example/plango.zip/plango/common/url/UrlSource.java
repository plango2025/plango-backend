package com.example.plango.common.url;

public enum UrlSource {
    FRONT,
    BACK,
    EXTERNAL
}
