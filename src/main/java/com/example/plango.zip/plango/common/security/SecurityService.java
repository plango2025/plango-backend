package com.example.plango.common.security;

import com.example.plango.user.model.UserInfo;

public interface SecurityService {
    UserInfo getUserInfo();
}