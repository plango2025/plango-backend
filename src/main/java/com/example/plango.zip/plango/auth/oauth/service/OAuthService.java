package com.example.plango.auth.oauth.service;

public interface OAuthService {
    String loginWithKakao(String code);
}
