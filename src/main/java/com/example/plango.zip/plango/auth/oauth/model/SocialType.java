package com.example.plango.auth.oauth.model;

public enum SocialType {
    KAKAO
}
