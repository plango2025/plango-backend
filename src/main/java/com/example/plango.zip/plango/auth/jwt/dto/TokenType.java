package com.example.plango.auth.jwt.dto;

public enum TokenType {
    ACCESS,
    REFRESH
}
